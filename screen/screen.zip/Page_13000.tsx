import React, { useContext } from 'react';
import { View, Text, TextInput, StyleSheet, ScrollView, Image, ImageBackground, TouchableOpacity } from 'react-native';
import { useRoute } from '@react-navigation/native';
import { deviceDataContext } from '../App';

const Page_13000 = ({ navigation, route }) => {
  const { deviceData, setDeviceData } = useContext(deviceDataContext);
  const { port } = route.params;

  return (
    <View style={styles.root}>
	<View >
		<View style={styles.intro}>
			<TouchableOpacity onPress={() => navigation.navigate('Page_13200')}>
				<Image style={styles.back_arrow} source={require('../images/arrow.png')}/>
				<Text style={styles.장치추가}>IP / 도메인으로 추가</Text>
				<View style={[styles.line, {top: 45, width: '100%'}]} />
			</TouchableOpacity>
		</View>
  
        <Text style={[styles.device_grp_name, ]}>카메라</Text>
		<View style={[styles.cameracontainer, {top: 110}]}>
			<TouchableOpacity  style={styles.Component1} onPress={() => navigation.navigate('Page_13100', { port, DEVTYPE:'C' } ) }>
				<View style={styles.device}>
					<Image style={styles.device_img} source={require('../images/live.png')}/>
					<Text style={styles.device_name}>네트워크 카메라</Text>
				</View>
			</TouchableOpacity>

			<View style={[{right:10}]}>
					<Text style={styles.device_name}>     </Text>
			</View>

			<TouchableOpacity  style={styles.Component1} onPress={() => navigation.navigate('Page_13100', { port, DEVTYPE:'C' } ) }>
				<Image style={styles.device_img} source={require('../images/live.png')}/>
				<Text style={styles.device_name}>아날로그 카메라</Text>
			</TouchableOpacity>
		</View>
		
		<View style={[styles.cameracontainer, {top:210}]}>
			<TouchableOpacity  style={styles.Component1} onPress={() => navigation.navigate('Page_13100', { port, DEVTYPE:'C' } ) }>
				<Image style={styles.device_img} source={require('../images/live.png')}/>
				<Text style={styles.device_name}>PTZ</Text>
			</TouchableOpacity>
			<TouchableOpacity  style={styles.Component2} onPress={() => navigation.navigate('Page_13100', { port, DEVTYPE:'C' } ) }>
			</TouchableOpacity>
		</View>
			
		<View style={[styles.line_mid, {top:273}]}/>

        <Text style={[styles.device_grp_name, {top: 280}]}>저장장치</Text>
		<View style={[styles.cameracontainer, {top: 370}]}>
			<TouchableOpacity  style={styles.Component1} onPress={() => navigation.navigate('Page_13100', { port, DEVTYPE:'C' } ) }>
				<View style={styles.device}>
					<Image style={styles.device_img} source={require('../images/live.png')}/>
					<Text style={styles.device_name}>NVR</Text>
				</View>
			</TouchableOpacity>
			<View style={[{right:10}]}>
					<Text style={styles.device_name}>     </Text>
			</View>			
			<TouchableOpacity  style={styles.Component1} onPress={() => navigation.navigate('Page_13100', { port, DEVTYPE:'C' } ) }>
				<Image style={styles.device_img} source={require('../images/live.png')}/>
				<Text style={styles.device_name}>DVR</Text>
			</TouchableOpacity>
		</View>

		<View style={[styles.line_mid, {top:393}]}/>		
        <Text style={[styles.device_grp_name, {top: 400}]}>특수카메라</Text>
		<View style={[styles.cameracontainer, {top: 530}]}>
			<TouchableOpacity  style={styles.Component1} onPress={() => navigation.navigate('Page_13100', { port, DEVTYPE:'C' } ) }>
				<View style={styles.device}>
					<Image style={styles.device_img} source={require('../images/live.png')}/>
					<Text style={styles.device_name}>멀티캠</Text>
				</View>
			</TouchableOpacity>
			<View style={[{right:10}]}>
					<Text style={styles.device_name}>     </Text>
			</View>			
			<TouchableOpacity  style={styles.Component1} onPress={() => navigation.navigate('Page_13100', { port, DEVTYPE:'C' } ) }>
				<Image style={styles.device_img} source={require('../images/live.png')}/>
				<Text style={styles.device_name}>도어캡</Text>
			</TouchableOpacity>
		</View>
       </View>
    </View>
  );
};

const styles = StyleSheet.create({
root: {
	width: '100%', height: 800,
	backgroundColor:'#FFFFFF',
},

back_arrow: {
    position: 'absolute', left: 10, top: 11,
	width: 20, 
	height: 20,
},

장치추가: {
    position: 'absolute', left: 130, top: 11,
    fontFamily: 'Pretendard',
    fontStyle: 'normal',
    fontWeight: 400,
    fontSize: 18,
    lineHeight: 23,
    color: '#000000',
},

line: {
	borderColor: '#E0E0E0',
	backgroundColor: '#E0E0E0',
	borderWidth: 1,
	width: '100%',

},

line_mid: {
	borderColor: '#E0E0E0',
	backgroundColor: '#E0E0E0',
	borderWidth: 1,
	width: '100%',
	height:3,
},

device_grp_name: {
	top: 55,
    fontFamily: 'Pretendard',
    fontStyle: 'normal',
    fontWeight: 700,
    fontSize: 18,
    lineHeight: 28.8,
    marginTop: 5,
    color:'#322E7F',
	textAlign: 'center',
	alignItems: 'center',
},

device: {
	flexDirection: 'column',
	justifyContent: 'center',
},

device_img: {
	top: 2, left: 60,
	width: 40, 
	height: 40,
},

device_name: {
	position: 'relative', top:2,
    fontFamily: 'Pretendard',
    fontStyle: 'normal',
    fontWeight: 700,
    fontSize: 16,
    textAlign: 'center',
    color: '#000000',

},

text1: {
    position: 'absolute', left:60, top:100,
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: 700,
    fontSize: 14,
    lineHeight: 20,
    color: '#4D4D4D',
},

cameracontainer: {
    position: 'absolute', left: 30,
    flexDirection: 'row',
    justifyContent: 'space-between',
	widht: '80%',
	borderColor: '#2D2D2D',


},

Component1: {
    width:160, height: 80,
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 5,
	borderColor: '#E0E0E0',
	borderWidth: 1,
},

Component2: {
    width:'45%', height: 80,
    justifyContent: 'center',
},

});

export default Page_13000;
