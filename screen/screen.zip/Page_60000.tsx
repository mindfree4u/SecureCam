import React, { useState, useEffect } from 'react';
import { View, Text, NativeModules, TextInput, Image, TouchableOpacity, StyleSheet, ScrollView, Alert, Linking  } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import Footer from './Footer';


const Page_60000 = ({ navigation }) => {
const [selectedIconIndex, setSelectedIconIndex] = useState(5);
const [files, setFiles] = useState([]);                                  //FlieBrowerActivity.java 에서 가져온 녹화목록 저장용
const [itemsToRemove, setItemsToRemove] = useState([]);

const { FileBrowserModule } = NativeModules;

useEffect(() => {
  const unsubscribe = navigation.addListener('focus', () => {
    setSelectedIconIndex(5);
  });

  return unsubscribe;
}, [navigation]);

useFocusEffect(
  React.useCallback(() => {
    // 화면이 포커스를 얻었을 때 데이터를 다시 불러오는 함수 호출
    fetchFiles();
  }, [])
);

const fetchFiles = async () => {
    try {
      const fileList = await FileBrowserModule.getFiles();
      setFiles(fileList);
    } catch (error) {
      console.error(error);
    }
};

const removeItem = async (index) => {
FileBrowserModule.deleteFile(files[index])
                              .then(response => {
                                console.log(response); // 파일 삭제 성공
                              })
                              .catch(error => {
                                console.error(error); // 파일 삭제 실패 또는 오류
                              });

          const updatedFiles = [...files];
          updatedFiles.splice(index, 1);
          setFiles(updatedFiles);

};

const ViewPlayback = (index) => () => {
    let position = index;
    Linking.openURL(`company://Page_61100?position=${position}`);
};

const handleLogout = () => {
          Alert.alert(
              '로그아웃 하시겠습니까?',
              '로그아웃 시 모든 푸시를 받지 못합니다.',
              [
                { text: '예', onPress: () => navigation.navigate('Intro_10000') },
                { text: '아니오', onPress: () => {} },
              ]
            );
       };

  return (
    <>
    <View style={styles.root}>
        <View>
            <Text style={styles.My}>내정보</Text>
            <Text style={styles.text1}>파일</Text>
            <TouchableOpacity  onPress={() => navigation.navigate('Page_61000')} style={{position: 'absolute', left: '83%', top:105}}>
                <Text style={styles.text3}>더보기</Text>
            </TouchableOpacity>

                 {files.slice(0, 9).map((file, index) => (
                 <View key={index} style={{ flexDirection: 'row',  justifyContent: 'space-between', top: 120 + index * 15 }}>
                    <TouchableOpacity onPress={ViewPlayback(index)} style={{left:30 }}>
                        <Text style={styles.fileText}> {file} </Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => removeItem(index)} style={{right:30}}>
                        <Text>   X</Text>
                    </TouchableOpacity>
                 </View>
                 ))}

            <Text style={styles.text2}>로그아웃</Text>
            <TouchableOpacity onPress={handleLogout} style={styles.image1}>
                <Image source={require('../images/arrow2.png')} style={{ width: 10, height:14 }}/>
            </TouchableOpacity>
            <Text style={[styles.text2, {top: 600}]}>회원탈퇴</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Page_62000')} style={[styles.image1,{top:607}]}>
                <Image source={require('../images/arrow2.png')} style={{ width: 10, height:14 }}/>
            </TouchableOpacity>
        </View>
    </View>
    <Footer navigation={navigation} selectedIconIndex={selectedIconIndex} setSelectedIconIndex={setSelectedIconIndex} />
    </>
  );
};

const styles = StyleSheet.create({
root: {
	width: '100%', 

	flex:1,
	flexDirection: 'column',
	backgroundColor: '#FFFFFF',
},


My: {
    justifyContent: 'center', top: 21.1,
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: 700,
    fontSize: 16,
    lineHeight: 23,
    textAlign: 'center',
    color: '#000000',
},
text1: {
    position: 'absolute', left: '11.12%', top: 100,
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: 700,
    fontSize: 16,
    lineHeight: 23,
    color: '#000000',
},
text3: {
    fontFamily: 'Inter',
    fontStyle: 'normal',
    fontWeight: '400',
    fontSize: 14,
    lineHeight: 17,
    color: '#4D4D4D',
},
fileText: {
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: 400,
    fontSize: 14,
    lineHeight: 23,
    color: '#000000',
},
text2: {
    position: 'absolute', left: '11.12%', top: 550,
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: 400,
    fontSize: 16,
    lineHeight: 23,
    color: '#000000',
},
image1: {
    position: 'absolute', left: '85%', top: 557,
},
});

export default Page_60000;
