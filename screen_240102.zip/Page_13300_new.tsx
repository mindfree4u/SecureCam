import React, { useContext, useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity, NativeModules, DeviceEventEmitter } from 'react-native';
import { useRoute, useFocusEffect } from '@react-navigation/native';
import { deviceDataContext } from '../App';

const Page_13300 = ({ navigation }) => {
  let flag = false;
  const { deviceData, setDeviceData } = useContext(deviceDataContext);
  const [deviceInfos, setDeviceInfos] = useState([]);
  const { DeviceSearchModule } = NativeModules;

//화면업데이트
useFocusEffect(
  React.useCallback(() => {
    getdeviceInfos();
      }, [ ])
  );

const getdeviceInfos =() => {

  // 장치 검색 시작
  DeviceSearchModule.startSearchDevices();


  const subscription = DeviceEventEmitter.addListener('onDeviceFound', async(deviceInfo) => {
    flag =true;
    setDeviceInfos((prevDeviceInfos) => [...prevDeviceInfos, deviceInfo]);

    if (deviceInfo.length === 0 ) {
                navigation.navigate('Page_13200');
              }
  });
setTimeout(() => {
    if (!flag) {
        navigation.navigate('Page_13200');
    }
}, 500);

  // 컴포넌트가 언마운트될 때 이벤트 리스너 제거
  return () => {
    subscription.remove();

  };
};


  return (
        <ScrollView>
            <View style={styles.root}>
                <TouchableOpacity onPress={() => navigation.navigate('Page_13200')} style={styles.vector}>
                      <Image source={require('../images/arrow.png')} style={{width: 16.17, height: 19.8}} />
                    </TouchableOpacity>
                    <Text style={styles.장치추가}>장치추가</Text>
                    <Text style={styles.text1}>추가할 장치를 선택해 주세요.</Text>

                    <View style={styles.container1}>
                {deviceInfos.map((info) => (
                 <TouchableOpacity key={info.DEVINFO}
                        onPress={() => navigation.navigate('Page_13100', { DEVTYPE:info.DEVTYPE, IP:info.IP, port:'37777' })}>
                    <View style={styles.container2}>

					    <View >
					        <Image style = {styles.image} source={require('../images/NVR.png')} />
					    </View>
						<View key={info.DEVINFO}>
						    <Text style={styles.deviceText}>
						        {info.DEVINFO}
						    </Text>
					    </View>
                    </View>
  </TouchableOpacity>
                ))}
                </View>
            </View>
        </ScrollView>
  );
};

const styles = StyleSheet.create({
root: {
    position: 'relative', width: '100%', height: 800,
    justifyContent: 'center',
    alignItems: 'center'
},
vector: {
    position: 'absolute', left: 20, top: 21.1,
},
장치추가: {
    position: 'absolute', top: 19,
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: 700,
    fontSize: 16,
    lineHeight: 23,
    textAlign: 'center',
    color: '#000000',
},
text1: {
    position: 'absolute', top: 105,
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: 700,
    fontSize: 14,
    lineHeight: 21,
    color: '#4D4D4D',
},
container1:{
   position: 'absolute', left: 10, top: 140,
},

container2:{
    flex: 1,
    flexDirection: 'row',
	left: 10,
},

item: {
    flex: 1,
    overflow: 'hidden',
    position: 'relative',
    margin: 10
},

image: {
    flex: 1,
	width: 110,
	height: 30,
	top: 20,
  },

deviceText: {
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: 400,
    fontSize: 14,
    lineHeight: 21,
    color: '#4D4D4D',
    marginTop: 35,
	left: 15
  },
});


export default Page_13300;