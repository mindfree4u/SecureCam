import React, { useState, useEffect, useContext } from 'react';
import { View, Text, TextInput, Image, TouchableOpacity, StyleSheet, ScrollView, FlatList, Alert, Switch } from 'react-native';
import { useRoute } from '@react-navigation/native';
import Toggle from "react-native-toggle-element";

import axios from 'axios';
import { SaltContext } from '../App';

const Page_15200 = ({ navigation }) => {
   const route = useRoute();
   const { eqpmnt_info_sn } = route.params || '';
   const saltContext = useContext(SaltContext);
   const salt_vl = saltContext.salt;
   const [shareId, setShareId] = useState('');                         //공유할 ID 저장용
    const [emails, setEmails] = useState([]);
   const [shrMbrSn, setShrMbrSn] = useState([]);

   const [eqpmntInfoSn, setEqpmntInfoSn ] = useState([]);

   const [eqpmntShrYn, setEqpmntShrYn] = useState([]);
   const [filteredEmails, setFilteredEmails] = useState([]);
   const [viewpermit, setViewpermit] = useState('허용');               //라이브뷰 허용/비허용
   const [recordpermit, setRecordpermit] = useState('비허용');         //녹화된영상 허용/비허용
   const [alarmpermit, setAlarmpermit] = useState('비허용');           //푸쉬알람 허용/비허용
   const [controlpermit, setControlpermit] = useState('비허용');  

const [toggleValue, setToggleValue] = useState(false);

   //장치제어 허용/비허용


const [isEnabled, setIsEnabled] = useState(false);


//화면시작시 공유된 씨가드계정 가져오기 시작
    useEffect(() => {
    const GetShareID = async () => {
         //기기공유목록 API 시작
         const MshareListdata = {
            salt_vl: salt_vl,
         };
         const MshareListurl = 'http://seeguard.ggulb.net/MshareList';

         // Axios를 사용하여 GET 요청 보내기
         axios
         .get(MshareListurl, { params: MshareListdata })
         .then((response) => {
            console.log('기기공유목록 응답 데이터:', response.data);
            setShrMbrSn(response.data.map(item => item.shr_mbr_sn));

			setEqpmntInfoSn(response.data.map(item => item.eqpmnt_info_sn));
			setEqpmntShrYn(response.data.map(item => item.eqpmnt_shr_yn));
            setEmails(response.data
                                      .filter(item => item.eqpmnt_shr_yn === 'Y')
                                      .map(item => item.eml_addr));

    // setEmails(['rhdy@gmail.com', 'rhdy7889898080805@gmail.com', 'rhdy745574645464564333543@gmail.com', 'test@gmai.com', 'test4444@naver.com', 'eheyyr@daum.net']);
         })
         };
         //기기공유목록 API 끝
    GetShareID();
    }, []);
//화면시작시 공유된 씨가드계정 가져오기 끝

const handlePermitToggle = (permitSetter) => {
           permitSetter((prevPermit) => {
               const newPermit = (prevPermit === '허용' ? '비허용' : '허용');
               return newPermit;
             });
           };

//공유할 ID입력시 호출됨
const handleShareID = (text) => {
      setShareId(text);
    };

// 공유하기 버튼 클릭시 호출됨
const handleShare =() => {
    if (shareId.length === 0) {
        Alert.alert('', '공유할 ID를 입력해 주세요.', [{ text: '확인' }]);
    }
    else if (!shareId || !shareId.includes('@') || !shareId.includes('.')) {
        Alert.alert( '','공유할 ID 형식이 올바르지 않습니다.', [{ text: '확인' }]);
    }
    else if(emails.length > 5) {
        Alert.alert('', '최대 6명까지 공유할 수 있습니다.', [{ text: '확인' }]);
    }
    else {

	const toggleSwitch = () => setIsEnabled(previousState => !previousState);
      <Switch
        trackColor={{false: '#767577', true: '#81b0ff'}}
        thumbColor={isEnabled ? '#f5dd4b' : '#f4f3f4'}
        ios_backgroundColor="#3e3e3e"
        onValueChange={toggleSwitch}
        viewpermitValue={isEnabled}
      />



    const viewpermitValue = viewpermit === '허용' ? '1' : '0';
    const recordpermitValue = recordpermit === '허용' ? '1' : '0';
    const alarmpermitValue = alarmpermit === '허용' ? '1' : '0';
    const controlpermitValue = controlpermit === '허용' ? '1' : '0';

    // 변환된 값을 문자열로 연결하여 eqpmnt_shr_role에 할당
    const eqpmnt_shr_role = viewpermitValue + recordpermitValue + alarmpermitValue + controlpermitValue;

        //기기공유등록 API 시작
        const MshareAdddata = {
            eml_addr: shareId,
            salt_vl: salt_vl,
            eqpmnt_info_sn: eqpmnt_info_sn,
            eqpmnt_shr_role: eqpmnt_shr_role,
        };
        const MshareAddurl = 'http://seeguard.ggulb.net/MshareAdd';

        // Axios를 사용하여 GET 요청 보내기
        axios
        .get(MshareAddurl, { params: MshareAdddata })
        .then((response) => {
            console.log('기기공유등록 응답 데이터:', response.data);
            if (response.data.rtnCode === "1") {
                            Alert.alert('', '장치공유 요청을 보냈습니다', [{ text: '확인' }]);
                        }
            else if (response.data.rtnCode === "0") {
                Alert.alert('', response.data.rtnMsg, [{ text: '확인' }]);
            }
        })
        .catch((error) => {
            console.error('기기공유등록 오류 발생:', error);
        });
    }
};

const removeItem = async (index) => {
  try {
   Alert.alert(
           `${emails[index]} 님과의 공유를 취소하시겠습니까 ?`,
                '',
          [
            { text: '취소', onPress: () => {

            }},
            { text: '확인', onPress: async () => {
          //기기공유삭제 API 시작
          const MshareDeldata = {
              salt_vl: salt_vl,
              shr_mbr_sn: shrMbrSn[index],
              eqpmnt_info_sn: eqpmntInfoSn[index],
          };
          const MshareDelurl = 'http://seeguard.ggulb.net/MshareDel';

          console.log('salt_vl:', salt_vl);
          console.log('공유대상자 SN:', shrMbrSn[index]);
		  console.log('eqpmnt_info_sn:', eqpmntInfoSn[index]);

          // Axios를 사용하여 GET 요청 보내기
          axios
          .get(MshareDelurl, { params: MshareDeldata })
          .then((response) => {
              console.log('기기공유삭제  데이터:', response.data);
              if (response.data.rtnCode === "1") {
                              const newEmails = [...emails];
                              newEmails.splice(index, 1);
                              setEmails(newEmails);
                          }
          })
          .catch((error) => {
              console.error('기기공유삭제 오류 발생:', error);
          });
        }},
        ]
      );
  } catch (error) {
    console.error('삭제 실패: ', error);
  }
};

  return (
  
      <View style={styles.root}>
	<View >
		<View style={styles.intro}>
            <TouchableOpacity onPress={()=> navigation.goBack()}>
				<Image style={styles.back_arrow} source={require('../images/arrow.png')}/>

			</TouchableOpacity>
			<Text style={styles.장치공유}>장치공유</Text>
			<View style={[styles.line, {top: 45, width: '100%'}]} />
		</View>  
		
        <Text style={styles.text0}>공유된 계정</Text>

        <View style={{  margin: 10, marginLeft: 20, marginTop: 120}}>
            <FlatList data={emails}  keyExtractor={(item, index) => index.toString()}
            renderItem={({ item, index  }) => (
                <TouchableOpacity onPress={() => removeItem(index)} style={{ marginBottom: 15 }}>
                    <View style={styles.email_id}>
					    <Image source={require('../images/person.png')} style={{ width: 13.02, height: 15.81, marginLeft: 10 }}/>
                        <Text numberOfLines={1} ellipsizeMode="tail" style={{ left: 10, top: -2, fontSize: 16, color: '#4F4F4F', flexShrink: 1 }}>{item}</Text>
                        <Image source={require('../images/Close.png')} style={{ width: 10, height: 10, marginLeft: 120 }}/>
                    </View>
                </TouchableOpacity>
            )}
            />
        </View>

		<View style={[{backgroundColor: '#FFFFFF', height: 500}]}>
			<View style={[styles.line, {top: 140, width: '100%'}]} />
				
			<Text style={[styles.text1, {top:160, left: '30%'}]}>새로운 공유계정 추가</Text>
			<Text style={[styles.text1, {top:190, fontSize: 14, lineHeight: 20}]}>추가할 ID</Text>
			<Text style={ styles.text2 }>최대 6명까지 추가 가능합니다.</Text>
			
			<View style={styles.square}/>
			<TextInput style={styles.textinput} value={shareId}  onChangeText={handleShareID} maxLength={20}
												placeholder="공유할 ID입력" placeholderTextColor="#4D4D4D" />
			<View style={[styles.line, {top: 280, width: '100%'}]} />
			
			<Text style={[styles.text3, {top: 300}]}>라이브뷰</Text>
			<TouchableOpacity style={[styles.touchable, { flex: 1, left: '76%', top: 300 }]} onPress={() => handlePermitToggle(setViewpermit)}>
					<Text style={styles.text4}>{viewpermit}</Text>
			</TouchableOpacity>
			<View style={[styles.line, {top: 330, width: '100%'}]} />
			
			<Text style={[styles.text3, {top: 352}]}>녹화된 영상</Text>
			<TouchableOpacity style={[styles.touchable, { flex: 1, left: '76%', top: 352} ]} onPress={() => handlePermitToggle(setRecordpermit)}>
					<Text style={styles.text4}>{recordpermit}</Text>
			</TouchableOpacity>
			<View style={[styles.line, {top: 380, width: '100%'}]} />
			
			<Text style={[styles.text3, {top: 403}]}>푸쉬알림</Text>
			<TouchableOpacity style={[styles.touchable,  { flex: 1, left: '76%', top: 403}]} onPress={() => handlePermitToggle(setAlarmpermit)}>
					<Text style={styles.text4}>{alarmpermit}</Text>
			</TouchableOpacity>
			<View style={[styles.line, {top: 430, width: '100%'}]} />
			<Text style={[styles.text3, {top: 455}]}>장치제어</Text>
			<TouchableOpacity style={[styles.touchable, { flex: 1, left: '76%', top: 455}]} onPress={() => handlePermitToggle(setControlpermit)}>
					<Text style={styles.text4}>{controlpermit}</Text>
			</TouchableOpacity>
			<View style={[styles.line, {top: 480, width: '100%'}]} />
			<TouchableOpacity style={[styles.Component1, { top:500 }]} onPress={handleShare}>
				<Text style={styles.공유하기}>공유하기</Text>
			</TouchableOpacity>
        </View>
		</View>
    </View>
  );
};

const styles = StyleSheet.create({
root: {
	width: '100%',
	backgroundColor:'#FFFFFF',
},

back_arrow: {
    position: 'absolute', left: 10, top: 11,
	width: 20, 
	height: 20,
},

장치공유: {
    position: 'absolute', left: '37%', top: 11,
    fontFamily: 'Pretendard',
    fontStyle: 'normal',
    fontWeight: 400,
    fontSize: 18,
    lineHeight: 23,
    color: '#000000',
},

line: {
	borderColor: '#E0E0E0',
	backgroundColor: '#E0E0E0',
	borderWidth: 1,
	width: '100%',
},

email_id: {
	flexDirection: 'row', 
	alignItems: 'center', 
	borderColor: '#EEEEEE',
	backgroundColor: '#EEEEEE',
	borderWidth: 1,
	width: '100%',
	height: 40,
	margin: -5,
},


text0: {
    position: 'absolute', left:'30%', top:70,
    fontFamily: 'Pretendard',
    fontStyle: 'normal',
    fontWeight: 700,
    fontSize: 22,
    lineHeight: 26,
    color: '#4D4D4D',
	textAlign: 'center',
},
text1: {
    position: 'absolute', left: '5%', top: 80,
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: 700,
    fontSize: 16,
    lineHeight: 23,
    color: '#000000',
},
text2: {
    position: 'absolute', right: '5%', top: 193,
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: '400',
    fontSize: 14,
    lineHeight: 17,
    color: '#4D4D4D',
},
square:{
    position: 'absolute', left: '5%', right: '5%', top: 220,
    backgroundColor: '#FFFFFF',                                // 배경색을 투명하게 설정
    height: 44,
    borderWidth: 1,                                              // 테두리 두께 설정
    borderColor: '#D6D9EB',                                        // 테두리 색상 설정
    borderRadius: 1,
},
textinput: {
    position: 'absolute', left: '9%', top: 217, width: '73%',
    fontFamily: 'Inter',
    fontStyle: 'normal',
    fontWeight: '400',
    fontSize: 14,
    lineHeight: 17,
    color: '#4D4D4D',
},
text3: {
    position: 'absolute',  left: '7%',
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: '700',
    fontSize: 16,
    lineHeight: 17,
    color: '#4D4D4D',
},

touchable: {
    position: 'absolute', right: '10%', width: 100,
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: '400',
    fontSize: 16,
    lineHeight: 17,
    color: '#4D4D4D',
},
text4: {

    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: '700',
    fontSize: 16,
    lineHeight: 17,
    color:'#943deb',
	textAlign: 'center',
	alignItems: 'center',
	justifyContent: 'center',
},
Component1: {
    position: 'absolute', left: '5%', right: '5%', top: 444, height: 44,

    justifyContent: 'center',
    backgroundColor: '#4543BA',
    borderRadius: 5,
},
공유하기: {
    fontFamily: 'Noto Sans KR',
    fontStyle: 'normal',
    fontWeight: 700,
    fontSize: 16,
    lineHeight: 17,
    textAlign: 'center',
    color: '#FFFFFF',
},
});

export default Page_15200;